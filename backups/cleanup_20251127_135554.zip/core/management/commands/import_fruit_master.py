from django.core.management.base import BaseCommand
from core.models import Product
try:
    # Optional: Some databases may not have FruitMaster model
    from core.models import FruitMaster  # type: ignore
except Exception:  # pragma: no cover - fallback for older schemas
    FruitMaster = None
import re

class Command(BaseCommand):
    help = "Populate FruitMaster table from existing Product records"

    def handle(self, *args, **options):
        created = 0
        if FruitMaster is None:
            self.stdout.write(self.style.WARNING('FruitMaster model not available. Nothing to import.'))
            self.stdout.write('Import completed')
            return
        for p in Product.objects.all():
            name = p.name.strip().lstrip("'").rstrip("'")
            variant = ''
            # extract variant inside first parentheses in name
            m = re.search(r"\(([^)]+)\)", name)
            if m:
                variant = m.group(1).strip()
                name = re.sub(r"\s*\([^)]*\)", "", name).strip()
            quantity_unit = (p.quantity_unit or '').strip()
            obj, is_created = FruitMaster.objects.get_or_create(name=name, variant=variant, size=quantity_unit)
            if is_created:
                created += 1

        # built-in extra fruits not in Product table
        extras = [
            ("Banana", "Cavendish", "Large"),
            ("Banana", "Lakatan", "Medium"),
            ("Mango", "Carabao", "16-18"),
            ("Mango", "Tommy Atkins", "Large"),
            ("Pineapple", "Queen", "Medium"),
            ("Strawberry", "Fresh", "Small"),
            ("Blueberry", "Fresh", "Small"),
            ("Watermelon", "Seedless", "5kg"),
        ]
        for name, variant, size in extras:
            _, is_created = FruitMaster.objects.get_or_create(name=name, variant=variant, size=size)
            if is_created:
                created += 1
        self.stdout.write(self.style.SUCCESS(f"Imported {created} fruit master records."))
        self.stdout.write('Import completed')